(function(){
angular.module('demo-app', ['ionic', 'demo-app.controllers'])
var app = angular.module('demo-app', ['ionic', 'demo-app.controllers','angularMoment']);

app.run(function($ionicPlatform) {
  
   $ionicPlatform.ready(function() {
     if (window.cordova && window.cordova.plugins.Keyboard) {
     
       
       cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
angular.module('demo-app', ['ionic', 'demo-app.controllers','angularMoment'])
       StatusBar.styleDefault();
      
     }
     })
   });
   });


 
 

app.config(function($stateProvider, $urlRouterProvider) {
   $stateProvider
   $stateProvider
     .state('demo-app', {
  
     
     url: '/app',
     abstract: true,
    templateUrl: 'templates/signupseller.html',
   controller: 'AppCtrl'
  })
  });

 $stateProvider.state('app.home', {
     url: '/home',
    
   
     views:{
   
       'menuContent': {

         controllerAs:'home'
     
       }
       }
     }
     }
-  })
+  });
-    .state('app.seller', {
+  $stateProvider.state('app.seller', {
       url: '/seller',
       url: '/seller',
       views: {
       views: {
         'menuContent': {
         'menuContent': {
 angular.module('md_gate', ['ionic', 'md_gate.controllers','angularMoment'])
           controllerAs:'register'
           controllerAs:'register'
         }
         }
       }
       }
-    })
+    });
-    .state('app.buyer', {
+  $stateProvider.state('app.buyer', {
       url: '/buyer',
       url: '/buyer',
       views: {
       views: {
         'menuContent': {
         'menuContent': {
           templateUrl: 'templates/registerBuyer.html',
           templateUrl: 'templates/registerBuyer.html',
           controllerAs:'register'
           controllerAs:'register'
         }
         }
       }
       }
-    })
+    });
   $urlRouterProvider.otherwise('/app/home');
 });
 });
+
+}());